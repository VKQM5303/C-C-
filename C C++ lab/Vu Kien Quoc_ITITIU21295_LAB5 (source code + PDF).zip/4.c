#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
int firstClass(int totalSeats[])
{
    int counter;
    for (counter = 1; counter <= 5; counter++)
    {
        if (totalSeats[counter] == 0)
        {
            totalSeats[counter] = 1;
            printf("Your seat assignment is %d\n", totalSeats[counter]);
            return 0;
        }

    }
    return -1;
}
int economy(int totalSeats[])
{
    int counter;
    for (counter = 6; counter <= 10; counter++)
    {
        if (totalSeats[counter] == 0)
        {
            totalSeats[counter] = 1;
            printf("Your seat assignment is %d\n", totalSeats[counter]);
            return 0;
        }
    }
    return -1;
}
int main()
{
    int purchaseCode;
    int first = 0;
    int eco = 0;
    int totalSeats[10] = { 0 };
    char economyChoice;
    char firstClassChoice;
    printf("Type 1 for first class, 2 for economy: ");
    scanf("%d", &purchaseCode);
    while (purchaseCode > 0)
    {
        if (purchaseCode == 1)
        {
            first = firstClass(totalSeats);
            if (first == -1)
            {
                printf("The first class section is full\n");
                printf("Would you like to sit in the economy section (Y or N): ");
                scanf(" %c", &economyChoice);
                if(toupper(economyChoice == 'Y'))
                {
                    eco = economy(totalSeats);
                }
                if (toupper(economyChoice == 'N'))
                {
                    break;
                }
            }
            printf("Type 1 for first class, 2 for economy: ");
            scanf("%d", &purchaseCode);
        }
        else if (purchaseCode == 2)
        {
            eco = economy(totalSeats);
            if (eco == -1)
            {
                printf("The economy class section is full\n");
                printf("Would you like to sit in the first class section (Y or N): ");
                scanf(" %c", &firstClassChoice);

                if(toupper(firstClassChoice == 'Y'))
                {
                    first = firstClass(totalSeats);
                }
                if (toupper(firstClassChoice == 'N'))
                {
                    
                    printf("\nType 1 for first class ,2 for economy: ");
                    scanf("%d", &purchaseCode);
                }
            }
            printf("Type 1 for first class, 2 for economy: ");
            scanf("%d", &purchaseCode);
        }
        else if(purchaseCode == 3)
        {
            break;
        }
    }
return 0;
}