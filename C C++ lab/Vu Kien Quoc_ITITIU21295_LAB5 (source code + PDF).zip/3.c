#include <stdio.h>
int main (void)
{
    int n , q, i;
    printf("Enter an interger: ");
    scanf("%d", &n);
    if (n >= 1000)
    {
        q = n/1000;
        n %= 1000;
        for(i = 1; i <= q; i++)
            printf("M");
    }
    if (n >= 500)
    {
        q = n/500;
        n %= 500;
        for(i = 1;i <= q; i++)
            printf("D");
    }
    if (n >= 100)
    {
        q = n/100;
        n %= 100;
        for(i = 1;i <= q; i++)   
            printf("C");
    }
    if (n >= 50)
    {
        q = n/50;
        n %= 50;
        for(i = 1; i <= q; i++)
            printf("L");
    }
    if (n >= 10)
    {
        q = n/10;
        n %= 10;
        for(i = 1; i <= q; i++)
        printf("X");
    }
    if(n>=5)
    {
        q = n/5;
        n %= 5;
        for(i = 1; i <= q; i++)
            printf("V");
    }
    if(n>=1)
    {
        q = n/1;
        n %= 1;
        for(i = 1; i <= q; i++)
            printf("I");
    }
return 0;
}