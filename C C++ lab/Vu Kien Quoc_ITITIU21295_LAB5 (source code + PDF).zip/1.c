#include <stdio.h>
#include <ctype.h>
int main (void)
{
    char sentence[100];
    int count, cha, i;
    printf("Enter a sentence: ");
    for (i = 0;(sentence[i] = getchar()) != '\n' ; i++)
    {
        ;
    }
    sentence[i] = '\0';
    count = i;
    printf("Changed sentence: ");
    for (i = 0; i < count; i++)
    {
        cha = islower(sentence[i])? toupper(sentence[i]) :
tolower(sentence[i]);
        putchar(cha);
    }
    return 0;
}