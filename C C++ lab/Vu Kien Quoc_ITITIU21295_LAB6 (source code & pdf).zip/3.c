#include<stdio.h>
long add2Nums(long *, long *);
int main(void)
{
   long a, b, sum;
   printf("Input the first number: ");
   scanf("%ld", &a);
   printf("Input the second number: ");
   scanf("%ld", &b);   
   sum = add2Nums(&a, &b);
   printf("The sum of %ld and %ld is %ld\n\n", a, b, sum);
   return 0;
}
long add2Nums(long *n1, long *n2) 
{
   long sum;
   sum = *n1 + *n2;
   return sum;
}
