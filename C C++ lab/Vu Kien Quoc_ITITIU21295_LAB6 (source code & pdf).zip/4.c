#include<stdio.h>
void main(void) 
{
   int arr[10];
   int i, n, sum = 0;
   int *a;
   printf("Input the number of elements to store in the array (max 10): ");
   scanf("%d", &n);
   printf("Input %d number of elements in the array: \n", n);
   for(i = 0; i < n; i++)
   {
        printf("element - %d: ", i+1);
	    scanf("%d", &arr[i]);
   } 	
   a = arr;
   for (i = 0; i < n; i++) 
   {
        sum = sum + *a;
        a++;
   }
   printf("The sum of array is: %d\n\n", sum);
   return 0;
}