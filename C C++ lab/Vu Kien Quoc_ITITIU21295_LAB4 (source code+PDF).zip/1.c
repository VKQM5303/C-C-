#include <stdio.h>
#include <math.h>
double hypotenuse(double a, double b) 
{
    double c = sqrt(pow(a,2) + pow(b,2));
}
int main(void) 
{
    double x, y;
    while(1)
    {
        printf("Enter the a side of the triangle: ");
        scanf("%lf", &x);
        printf("Enter the b side of the triangle: ");
        scanf("%lf", &y);
        printf("Hypotenenuse: %lf\n", hypotenuse(x, y));
    }
    return 0;
}