#include <stdio.h>
int main()
{
    int n;
    while(1)
    {
        printf("Enter an interger: ");
        scanf("%d", &n);
        if (n % 2 == 0)
        {
            printf("%d is an even interger.\n", n);
        }
        else
        {
            printf("%d is an odd interger.\n", n);
        }
    }
    return 0;
}
