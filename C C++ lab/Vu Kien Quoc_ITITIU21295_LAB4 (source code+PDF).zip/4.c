#include <stdio.h>
int main (void)
{
    int BiCoef = 1, line, i, j;
    printf("Enter an interger number: ");
    scanf("%d", &line);
    printf("");
    for(i = 0; i < line; i++)
    {
        for(j = 0; j <= i; j++)
        {
            if (j == 0 || i == 0)
            BiCoef = 1;
            else
            BiCoef = BiCoef * (i - j + 1)/j;
            printf("%3d", BiCoef);
        }
        printf("\n");
    }
    return 0;
}