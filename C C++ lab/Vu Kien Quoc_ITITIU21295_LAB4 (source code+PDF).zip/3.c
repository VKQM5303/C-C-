#include <stdio.h>
#include <stdlib.h>
int main (void)
{
    int n, guess;
    srand(0);
    n = rand() % 1000 + 1; 
    printf("I have a number between 1 and 1000.\nCan you guess my number?\n");
    do
    {
        printf("Please enter your number: ");
        scanf("%d", &guess);
        if (guess > n)
        {
            printf("Too high! Try again.\n\n");
        }
        else if (guess < n)
        {
            printf("Too low! Try again.\n\n");
        }
        else
        {
            printf("\nExcellent! You guessed the number!\nWould you like to play again (y or n)?");
        }
    }
    while (guess != n);
    return 0;
}